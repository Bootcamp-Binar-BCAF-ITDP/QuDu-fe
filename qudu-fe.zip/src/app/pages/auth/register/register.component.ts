import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.services';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './register.component.html',
})
export class RegisterComponent {
  loading = false;
  showPassword = false;
  errorMessage = '';

  registerForm;

  constructor(
    private readonly fb: FormBuilder,
    private readonly authService: AuthService,
  ) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      fullName: ['', Validators.required],
      accountType: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      roleId: ['', Validators.required],
      branchId: ['', Validators.required],
    });
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  register(): void {
    this.errorMessage = '';

    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    this.loading = true;

    const request = {
      username: this.registerForm.get('username')?.value ?? '',

      email: this.registerForm.get('email')?.value ?? '',

      password: this.registerForm.get('password')?.value ?? '',

      fullName: this.registerForm.get('fullName')?.value ?? '',

      accountType: 'USER',

      phoneNumber: this.registerForm.get('phoneNumber')?.value ?? '',

      roleId: this.registerForm.get('roleId')?.value ?? 0,

      branchId: this.registerForm.get('branchId')?.value ?? 0,
    };

    this.authService.register(request).subscribe({
      next: (response) => {
        this.loading = false;
      },

      error: (error) => {
        console.error('Registration error:', error);
        this.loading = false;

        if (error.status === 401) {
          this.errorMessage = 'Invalid registration details.';
        } else {
          this.errorMessage = 'An error occurred during registration. Please try again.';
        }
      },
    });
  }
}
